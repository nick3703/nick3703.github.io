# bs.example.R
# for CASD 2016
##############################################################################

# Explore 1974 Motor Trend Cars Road Tests Data
?mtcars
head(mtcars)
n = dim(mtcars)[1]
mtcars.lm = lm(mpg~wt+disp, data=mtcars)
summary(mtcars.lm)

##############################################################################

# Typical CI for regression coefficients
# Built in...
alpha = 0.05
confint(mtcars.lm, level = 1-alpha)
# ...or by hand
Y = mtcars$mpg
X = cbind(rep(1,n),mtcars$wt,mtcars$disp)
XtXinv = solve(t(X)%*%X)
b = XtXinv%*%t(X)%*%Y
Yhat = X%*%b
p = dim(X)[2]
e = Y-Yhat
S2 = t(e)%*%e/(n-p) 
Vb = diag(S2[1]*XtXinv)
SEb = sqrt(Vb)
CIs.normal = cbind(b-qt(1-alpha/2,n-p)*SEb,b+qt(1-alpha/2,n-p)*SEb)

##############################################################################

# Typical CI for regression coefficients
# Bootstrap CI for beta.wt
B = 10000
bs.stats = numeric(B)
set.seed(1991)
for (ii in 1:B){
  bs.mtcars = mtcars[sample(n,replace = TRUE),]
  bs.mtcars.lm = lm(mpg~wt+disp, data=bs.mtcars)
  bs.stats[ii] = coef(bs.mtcars.lm)[2]
}

hist(bs.stats,freq=FALSE,breaks=40)
CI.bs=quantile(bs.stats, c(alpha/2,1-alpha/2))
CI.bs
abline(v = CI.bs, lwd=3, col=3)
CIs.normal[2,]
abline(v = CIs.normal[2,], lwd=3, col=2)
this.cex = 1.5
legend("topright", 
       legend = c(paste(100*(1-alpha),"% CI (bootstrap)",sep=""),
                  paste(100*(1-alpha),"% CI (conventional)",sep="")), 
       col = c(3,2), lty = 1, lwd=3, cex = this.cex, pt.cex=this.cex)



##############################################################################