# pt.example.R
# for CASD 2016
##############################################################################

# Import heart.data and heart.class
this.dir = "<your path to these data>"

# Predictors
heart.data = read.csv(paste(this.dir,"/heart.data.csv",sep=""))

# Class
heart.class = read.csv(paste(this.dir,"/heart.class.csv",sep=""))

# Number of observations
N = dim(heart.data)[1]

##############################################################################

#Simple example using trestbps
# Diseased group (139)
bps1 = heart.data$trestbps[heart.class==1]
length(bps1)
# Well group (164)
bps2 = heart.data$trestbps[heart.class==2]
length(bps2)

hist(bps2, col=rgb(0.8,0.8,0.8,0.5), xlim=c(min(bps2),max(bps1)), 
     main="Overlapping Histogram", xlab="Variable")
hist(bps1, col=rgb(0.1,0.1,0.1,0.5), add=TRUE)
box()

# Standard test for difference
t.test(bps1,bps2)
qqnorm(bps1)
qqline(bps1)
qqnorm(bps2)
qqline(bps2)

##############################################################################

# Permutation test (correct labels, univariate)
Tstat = function(x,y) (mean(x)-mean(y))/sqrt(var(x)/length(x)+var(y)/length(y))
T0 = Tstat(bps1,bps2)
num.perms = 10000
T = numeric(num.perms)
set.seed(1991)
for (ii in 1:num.perms){
  perm.class = sample(N)
  perm.bps1 = heart.data$trestbps[perm.class[heart.class==1]]
  perm.bps2 = heart.data$trestbps[perm.class[heart.class==2]]
  T[ii] = Tstat(perm.bps1,perm.bps2)
}
hist(T)
abline(v = T0, lwd=3, col=2)
m = mean(T>=T0)
text(3.5, 1800, 
     paste(round(100*m,2),"% of\nrandomized\nT's are >= T0",sep=""), 
     col=2, cex=1.5)
text(3.5, 1200, paste("=> approx.\np-value is\n",2*m,sep=""), col=1, cex=1.5)

##############################################################################

# Permutation test (tainted labels, univariate)
n.bad = 227   # shuffle 75% of labels
inds.bad = sample(n.bad)
heart.class.bad = heart.class
shuffle.bad = sample(inds.bad)
heart.class.bad[inds.bad,] = heart.class.bad[shuffle.bad,]

# "Tainted" diseased group (139)
bps1.bad = heart.data$trestbps[heart.class.bad==1]
length(bps1.bad)
# "Tainted" well group (164)
bps2.bad = heart.data$trestbps[heart.class.bad==2]
length(bps2.bad)

T0.bad = Tstat(bps1.bad,bps2.bad)
T.bad = numeric(num.perms)
set.seed(1991)
for (ii in 1:num.perms){
  perm.class = sample(N)
  perm.bps1 = heart.data$trestbps[perm.class[heart.class.bad==1]]
  perm.bps2 = heart.data$trestbps[perm.class[heart.class.bad==2]]
  T.bad[ii] = Tstat(perm.bps1,perm.bps2)
}
hist(T.bad)
abline(v = T0.bad, lwd=3, col=2)
m.badr = mean(T.bad>=T0.bad)
m.badl = mean(T.bad<=T0.bad)
if (m.badr<m.badl){
  m.bad = m.badr
  text(2.5, 1800, 
       paste(round(100*m.bad,2),"% of\nrandomized\nT's are >= T0",sep=""), 
       col=2, cex=1.5)
  text(2.5, 1200, paste("=> approx.\np-value is\n",2*m.bad,sep=""), col=1, 
       cex=1.5)
}
if (m.badr>m.badl){
  m.bad = m.badl
  text(-2.5, 1800, 
       paste(round(100*m.bad,2),"% of\nrandomized\nT's are <= T0",sep=""), 
       col=2, cex=1.5)
  text(-2.5, 1200, paste("=> approx.\np-value is\n",2*m.bad,sep=""), col=1, 
       cex=1.5)
}

##############################################################################
library("AcrossTic")
?rRegMatch

# Permutation test (tainted labels, MULTIvariate)
r = 100
y = heart.class.bad[,1]
D = daisy(heart.data)
t0 = proc.time()[3]
my.acobj = rRegMatch(D, r = r, y = y, relax = FALSE)
t1 = round(proc.time()[3] - t0, 1)
cat(paste("That took",t1,"seconds.\n"))
set.seed(1991)
ptest(my.acobj)
