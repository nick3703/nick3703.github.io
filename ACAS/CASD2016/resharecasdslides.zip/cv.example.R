# cv.example.R
# for CASD 2016
##############################################################################

# Load "class" library to use knn()
library("class")
# Source cv.inds.R for CV:
source('cv.inds.R')

# Import heart.data and heart.class
this.dir = "<your path to these data>"

# Predictors
heart.data = read.csv(paste(this.dir,"/heart.data.csv",sep=""))

# Class
heart.class = read.csv(paste(this.dir,"/heart.class.csv",sep=""))

# Number of observations
N = dim(heart.data)[1]

##############################################################################

# Use quantitative predictors only for kNN 
quants = c(1,4,5,8,10)

# Remove 53 of 303 observations as test data
keep = 250
train.heart = heart.data[1:keep,quants]
train.class = heart.class[1:keep,]
test.heart = heart.data[(keep+1):N,quants]
test.class = heart.class[(keep+1):N,]

# Number of folds for cross-validation
K = 10

##############################################################################

# Compare kNN error rates for training date compared to test data
k.vec = 1:10   # Number of nearest neighbors for kNN
error.rate.test = numeric(length(k.vec))
error.rate.train = error.rate.test

# Compute error rates for varying neighborhood sizes
for (kk in k.vec){
  set.seed(1)
  pred.knn.test = knn(train = train.heart, test = test.heart, 
                 cl = train.class, k = kk)
  pred.knn.train = knn(train = train.heart, test = train.heart, 
                      cl = train.class, k = kk)
  error.rate.test[kk] = mean(pred.knn.test!=test.class)
  error.rate.train[kk] = mean(pred.knn.train!=train.class)
}

this.cex = 1.5
plot(k.vec,error.rate.test,ylim = c(0,.6),
     xlab = "Number of neighbors (k)", ylab = "Misclassification error", 
     pch = 19, cex = this.cex, cex.lab = this.cex, cex.main = this.cex,
     main = "Misclassification error for varying neighborhood sizes")
points(k.vec,error.rate.train,col=2, pch = 19, cex = this.cex)
lines(k.vec,error.rate.test)
lines(k.vec,error.rate.train)
legend("topright", legend = c("Test error","Training error",
                              paste(K,"-fold CV error",sep="")), 
       col = 1:3, lty = 1, pch = 19, cex = this.cex, pt.cex=this.cex)

##############################################################################

# Now compare with K-fold cross validation
error.rate.cv = numeric(length(k.vec))

# Use homemade function "cv.inds" for sampling w/o replacement
test.fold = cv.inds(train.heart,K)
for (kk in k.vec){
  errors.cv = numeric(K)
  for(ii in 1:K){
    this.test = train.heart[test.fold==ii,]
    this.train = train.heart[test.fold!=ii,]
    this.class = train.class[test.fold!=ii]
    pred.knn.cv = knn(train = this.train, test = this.test, 
                      cl = this.class, k = kk)
    errors.cv[ii] = mean(pred.knn.cv!=train.class[test.fold==ii])
  }
  error.rate.cv[kk] = mean(errors.cv)
}

points(k.vec,error.rate.cv,col=3, pch = 19, cex = this.cex)
lines(k.vec,error.rate.cv)

##############################################################################