# cv.inds produces row indices for K folds of test data
# DMR 10/16
# INPUTS:
# - data = the data
# - K    = number of folds
# - seed = optional value (for reproducibility)
# OUTPUTS:
# - test.fold = vector of fold indices

cv.inds = function(data, K, seed = 1){
  set.seed(seed)
  n = dim(data)[1]
  test.fold = numeric(n)
  fold.size = floor(n/K)
  remainder = n%%fold.size
  sample.vec = sample(n)
  for (ii in 1:K){
    test.fold[sample.vec[((ii-1)*fold.size+1):(ii*fold.size)]] = ii
  }
  test.fold[test.fold==0] = sample(1:K,remainder)
  return(test.fold)
}